using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using TestEngine.GFX.Sprite;

namespace GameDemo
{

    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        CPlayer mySprite;
        CBullet bullet;
        Enemy enemy;
        

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);

            mySprite = new CPlayer();
            mySprite.graphics = this.graphics;

            bullet = new CBullet();

            enemy = new Enemy();

            Content.RootDirectory = "Content";
        }


        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }


        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            //We use the instance of the Sprite class to access it's load method
            mySprite.Load("player", this.Content); 
            mySprite.Height = 70;
            mySprite.Width = 70;
            mySprite.Speed = 3;
            mySprite.y = GraphicsDevice.Viewport.Height - mySprite.Height;

            bullet.Load("bullet", this.Content);
            bullet.Speed = 3;
            bullet.Height = 40;
            bullet.Width = 10;
            bullet.visible = false;

            enemy.Load("enemy", this.Content);
            enemy.Height = 50;
            enemy.Width = 100;
        }


        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }


        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit

            try
            {
                Keys key = Keyboard.GetState().GetPressedKeys()[0];
                mySprite.Update(key);

                //GamePadState gamePad = GamePad.GetState(PlayerIndex.One);
                //mySprite.Update(gamePad);
            }
            catch
            {
                //do nothing
            }

            bullet.Update();
            

            base.Update(gameTime);
        }


        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            spriteBatch.Begin();

            bullet.Draw(spriteBatch);
            enemy.Draw(spriteBatch);
            mySprite.Draw(spriteBatch);

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
