﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework;

namespace TestEngine.GFX.Sprite
{
    public class CBullet : CSprite
    {
        Boolean alive;

        public void Create()
        {
            if (!alive)
            {
                alive = true;
                visible = true;
            }
        }

        public override void Update()
        {
            if (y + this.Height > 0 && alive == true)
            {
                y -= Speed;
            }
            else
            {
                alive = false;
                visible = false;
            }
                

            base.Update();
        }
    }
}
