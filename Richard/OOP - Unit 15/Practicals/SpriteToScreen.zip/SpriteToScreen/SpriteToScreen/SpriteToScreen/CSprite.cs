﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Input;


namespace SpriteToScreen
{
    class CSprite
    {
        public Texture2D imageFile;
        public int x, y;

        public void Load(ContentManager Content, string filename)
        {
            imageFile = Content.Load<Texture2D>(filename);
        }

        public void Update()
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Up))
                y -= 3;
            if (Keyboard.GetState().IsKeyDown(Keys.Down))
                y += 3;
            if (Keyboard.GetState().IsKeyDown(Keys.Right))
                x += 3;
            if (Keyboard.GetState().IsKeyDown(Keys.Left))
                x -= 3;

        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(imageFile, new Rectangle(x, y, imageFile.Width, imageFile.Height), Color.White);
        }
    }
}
