﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Input;

namespace TestEngine.GFX.Sprite
{
    public class CPlayer : CSprite
    {
        public override void Update(Keys K)
        {
            Keys key = Keyboard.GetState().GetPressedKeys()[0];

            switch (K)
            {
                case Keys.A:
                    //left
                    this._x -= Speed;
                    break;
                case Keys.D:
                    //right
                    this._x += Speed;
                    break;
                case Keys.W:
                    //up
                    this._y -= Speed;
                    break;
                case Keys.S:
                    //down
                    this._y += Speed;
                    break;
                case Keys.Space:
                    //fire
                    break;
                case Keys.RightControl:
                case Keys.LeftControl:
                    //alt fire
                    break;
                case Keys.Escape:
                    //exit
                    
                    break;
            }

            base.Update();
        }

        public override void Update(GamePadState gamePad)
        {
            //switch (b)
            //{
            //    case Buttons.DPadLeft:
            //        this.x -= Speed;
            //        break;
            //    case Buttons.DPadRight:
            //        this.x += Speed;
            //        break;
            //    case Buttons.DPadUp:
            //        this.y -= Speed;
            //        break;
            //    case Buttons.DPadDown:
            //        this.y += Speed;
            //        break;
            //}

            //if (gamePad.DPad.Down == ButtonState.Pressed)
            //{
            //    this.y += Speed;
            //}
            //else if (gamePad.DPad.Up == ButtonState.Pressed)
            //{
            //    this.y -= Speed;
            //}
            //else if (gamePad.DPad.Right == ButtonState.Pressed)
            //{
            //    this.x += Speed;
            //}
            //else if (gamePad.DPad.Left == ButtonState.Pressed)
            //{
            //    this.x -= Speed;
            //}


            this.y -= Speed * gamePad.ThumbSticks.Left.Y;
            this.x += Speed * gamePad.ThumbSticks.Left.X;
            
        }

    }
}
