﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace TestEngine.GFX.Sprite
{
    public class CSprite
    {
        //public member
        public GraphicsDeviceManager graphics;
        public CBullet bullet;

        //Global declartations
        Texture2D imgTexture;
        public float _x, _y;
        public int _Width, _Height;
        public int _Speed;
        bool _visible;


        //constructor
        public CSprite()
        { 
        }

        //Deconstructor
        ~CSprite()
        { 
        }

        //Properties
        public float x
        {
            set { _x = (int)value;}
            get { return _x;}
        }

        public float y
        {
            set { _y = (int)value;}
            get { return _y; }
        }

        public int Width
        {
            set { _Width = value; }
            get { return _Width; }
        }

        public int Height
        {
            set { _Height = value; }
            get { return _Height; }
        }

        public int Speed
        {
            get 
            {
               return _Speed; 
            }
            set 
            {
                if(value < 10)
                    _Speed = value; 
            }
        }

        public bool visible
        {
            set { _visible = value; }
            get { return _visible; }
        }

        //Methods
        public void Load(string assetName, ContentManager content)
        {
            imgTexture = content.Load<Texture2D>(assetName);
            _Width = imgTexture.Width;
            _Height = imgTexture.Height;
            _visible = true;
        }

        public virtual void Update()
        { 
        }

        public virtual void Update(Keys K)
        {
            
        }

        public virtual void Update(GamePadState gamePad)
        { 
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            if (_visible)
            {
                spriteBatch.Draw(imgTexture, BoundBox, Color.White);
            }
            
        }

        public void Fire()
        {
            bullet.x = (this.Width / 2) - (bullet.Width / 2);
            bullet.y = (this.Height / 2) - (bullet.Height / 2);
            bullet.Create();
        }

        //Specials
        public Rectangle BoundBox
        {
            get 
            {
                return new Rectangle((int)x, (int)y, Width, Height);
            }

        }

        public Boolean hasCollided(CSprite colSprite)
        {
            if (this.BoundBox.Intersects(colSprite.BoundBox))
            {
                return true;
            }

            return false;
        }
    }

    public class Enemy : CSprite
    {
        //int direction;
        public override void Update()
        {
            if (this.x < graphics.GraphicsDevice.Viewport.Width - Speed)
                this.x = this.x + Speed;
            else
                Speed *= -1;

            if (this.x < 0)
            {
                Speed *= -1;
                this.y += 10;
            }

            base.Update();
        }
    }
}
